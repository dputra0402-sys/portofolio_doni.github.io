# Doni Eka Putra — Autonomous Driving Data Portfolio

Portfolio website for Data Annotation Team Leader at KUPU ID (XIAOMI Autonomous Driving Project).

## 🚀 Live Site
[View Portfolio](https://doniputra.github.io/portfolio)

## 📁 Structure
```
portfolio/
├── index.html      # Main portfolio page
├── images/         # Annotation work sample screenshots
│   ├── sign_1.jpg  # 2D Traffic Sign annotation samples
│   ├── sign_2.jpg
│   ├── sign_3.jpg
│   ├── sign_4.jpg
│   ├── sem_1.jpg   # 3D Semantic Segmentation samples
│   ├── sem_2.jpg
│   ├── sem_3.jpg
│   ├── cub_1.jpg   # 4D LiDAR Cuboid samples
│   ├── cub_2.jpg
│   └── cub_3.jpg
└── README.md
